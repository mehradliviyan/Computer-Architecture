#include <stdio.h>

int main()
{
    int A[10] = {1 , 2 , 42 , 32 , 12 , 25 , 43 , 7 , -45 , 8} ;
    int max = A[0];

    for (int i = 0; i < 10; i++)
    {
        if (A[i] > max)
        {
            max = A[i];
        }
    }
    printf("%d" , max);
}