#include <stdio.h>

int main()
{
    int numbers [20] = {10 , 1 , 2 , 3 , 5 , 6 , 4 , 55 , 33 , 74 , 46 , 11 , 12 , 32 , 21 , 10 , 1 , 2 , 3 , 5};
    int i = 0;
    int swapTerm = 0;
    for (i = 0; i < 20; i++)
    {
        for (int j = i+1; j < 20; j++)
        {
            if (numbers[i] >= numbers[j])
            {
                swapTerm = numbers[i];
                numbers[i] = numbers[j];
                numbers[j] = swapTerm;
            }
        }
    }
    for (i = 0; i < 20; i++)
    {
        printf("%d \t %d\n" ,i , numbers[i] );
    }
    
}